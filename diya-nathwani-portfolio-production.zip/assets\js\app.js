/* ==========================================================================
   DIYA NATHWANI PORTFOLIO - CORE ENGINE (app.js)
   Lenis Smooth Scroll, GSAP Micro-Animations, and Complete Interactivity
   ========================================================================== */

import { drawers, services, journey, clientGroups, faqs, linkFor, PORTFOLIO_ROOT, ASSET_MAP } from './portfolio-data.js';

// Wait for DOM & libraries to load
document.addEventListener("DOMContentLoaded", () => {
  initLenisAndGSAP();
  initNavbar();
  initLiveClock();
  initLoaderAndHeroAnimation();
  initHeroAnimations();
  initQuickStatsCountup();
  initProofsExpand();
  initServicesAccordion();
  initWorkTabs();
  initJourneyTabs();
  initFaqAccordion();
  initTestimonialsSlider();
  initFavsCarousel();
  initLetterDetails();
  initScrollReveals();
  initClapperAnimation();
  initProcessCardsTilt();
  initMicroHoverEffects();
});

/* --------------------------------------------------------------------------
   1. LENIS SMOOTH SCROLL & GSAP SCROLLTRIGGER SYNC
   -------------------------------------------------------------------------- */
let lenis = null;

function initLenisAndGSAP() {
  // Initialize Lenis if available
  if (typeof window.Lenis !== "undefined") {
    lenis = new window.Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1.0,
      touchMultiplier: 1.5,
      infinite: false
    });

    // Make lenis globally available
    window.lenis = lenis;

    // Sync GSAP ScrollTrigger with Lenis
    if (typeof window.gsap !== "undefined" && typeof window.ScrollTrigger !== "undefined") {
      window.gsap.registerPlugin(window.ScrollTrigger);
      lenis.on('scroll', window.ScrollTrigger.update);
      window.gsap.ticker.add((time) => {
        lenis.raf(time * 1000);
      });
      window.gsap.ticker.lagSmoothing(0);
    } else {
      function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf);
      }
      requestAnimationFrame(raf);
    }
  }
}

// Helper to smooth scroll to an element or selector
function scrollToTarget(target, offset = -85) {
  if (lenis) {
    lenis.scrollTo(target, { offset, duration: 1.2 });
  } else {
    const el = typeof target === 'string' ? document.querySelector(target) : target;
    if (el) {
      const top = el.getBoundingClientRect().top + window.pageYOffset + offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  }
}

/* --------------------------------------------------------------------------
   2. NAVBAR NAVIGATION & ACTIVE SECTION HIGHLIGHT
   -------------------------------------------------------------------------- */
function initNavbar() {
  const navButtons = document.querySelectorAll('.nk-nav button');
  const sections = [
    { name: 'About', id: '#about' },
    { name: 'Results', id: '#results' },
    { name: 'Work', id: '#work' },
    { name: 'Journey', id: '#journey' },
    { name: 'Featured', id: '#featured' },
    { name: 'Media', id: '#media' }
  ];

  // Map each button to its section
  navButtons.forEach(btn => {
    const text = btn.textContent.trim().toLowerCase();
    const match = sections.find(s => s.name.toLowerCase() === text);
    if (match) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        scrollToTarget(match.id, -85);
      });
    }
  });

  // "Let's talk" buttons
  const talkButtons = document.querySelectorAll('.nk-bar .nk-btn, .nk-hero .nk-btn, a[href="#contact"]');
  talkButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const contactSec = document.querySelector('#contact');
      if (contactSec) {
        e.preventDefault();
        scrollToTarget('#contact', -85);
      }
    });
  });

  // "Read the lore" button in about section
  const loreBtn = document.querySelector('#about .nk-btn');
  if (loreBtn) {
    loreBtn.addEventListener('click', (e) => {
      e.preventDefault();
      scrollToTarget('#journey', -85);
    });
  }

  // Active section indicator on scroll using IntersectionObserver / ScrollTrigger
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = '#' + entry.target.id;
        const match = sections.find(s => s.id === id);
        if (match) {
          navButtons.forEach(btn => {
            if (btn.textContent.trim().toLowerCase() === match.name.toLowerCase()) {
              btn.classList.add('is-active');
            } else {
              btn.classList.remove('is-active');
            }
          });
        }
      }
    });
  }, { threshold: 0.35 });

  sections.forEach(s => {
    const el = document.querySelector(s.id);
    if (el) observer.observe(el);
  });
}

/* --------------------------------------------------------------------------
   3. REAL-TIME LIVE IST CLOCK
   -------------------------------------------------------------------------- */
function initLiveClock() {
  const clockEl = document.querySelector('.nk-clock');
  if (!clockEl) return;

  function updateClock() {
    // Current Indian Standard Time (UTC + 5:30)
    const now = new Date();
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const ist = new Date(utc + (3600000 * 5.5));
    
    let hours = ist.getHours();
    const minutes = String(ist.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 becomes 12

    const timeStr = `${hours}:${minutes} ${ampm}`;
    clockEl.innerHTML = `${timeStr}<small>IST, probably overthinking a headline</small>`;
  }

  updateClock();
  setInterval(updateClock, 1000);
}

/* --------------------------------------------------------------------------
   4. EDITORIAL PRELOADER & CHOREOGRAPHED HERO ENTRANCE
   -------------------------------------------------------------------------- */
function initLoaderAndHeroAnimation() {
  const loader = document.querySelector("#pageLoader");
  const percentEl = document.querySelector("#loaderPercent");
  const fillEl = document.querySelector("#loaderFill");
  const statusEl = document.querySelector("#loaderStatus");

  const statuses = [
    { p: 0, text: "Overthinking a headline..." },
    { p: 25, text: "Brewing strong hooks..." },
    { p: 55, text: "Calibrating data x drama..." },
    { p: 85, text: "Setting up the stage..." },
    { p: 100, text: "Ready to launch!" }
  ];

  let progress = 0;
  const duration = 1200; // 1.2s loader duration
  const startTime = performance.now();

  function updateLoader(now) {
    const elapsed = now - startTime;
    progress = Math.min(100, Math.round((elapsed / duration) * 100));

    if (percentEl) percentEl.textContent = `${progress}%`;
    if (fillEl) fillEl.style.width = `${progress}%`;

    const matchStatus = statuses.filter(s => progress >= s.p).pop();
    if (matchStatus && statusEl) statusEl.textContent = matchStatus.text;

    if (progress < 100) {
      requestAnimationFrame(updateLoader);
    } else {
      setTimeout(() => {
        dismissLoaderAndPlayHero();
      }, 160);
    }
  }

  requestAnimationFrame(updateLoader);

  function dismissLoaderAndPlayHero() {
    // 1. Remove hero-preload class so GSAP has full dynamic control
    const heroSection = document.querySelector(".nk-hero");
    if (heroSection) heroSection.classList.remove("hero-preload");

    // 2. Play the hero entrance simultaneously as the loader lifts
    playHeroEntrance();

    if (window.gsap && loader) {
      window.gsap.to(loader, {
        yPercent: -100,
        duration: 0.8,
        ease: "power4.inOut",
        onComplete: () => {
          loader.style.display = "none";
        }
      });
    } else {
      if (loader) loader.style.display = "none";
    }
  }

  function playHeroEntrance() {
    if (!window.gsap) return;

    const isDesktop = window.innerWidth >= 768;
    const heroTL = window.gsap.timeline();

    // 1. Center photo zooms & springs into place
    heroTL.fromTo(".nk-hero-photo",
      { scale: 0.72, opacity: 0 },
      { scale: 1, opacity: 1, duration: 0.7, ease: "back.out(1.6)" }
    );

    // 2. Diya letters emerge one-by-one from BEHIND the picture!
    heroTL.fromTo(".hn-big .hn-l",
      { y: 90, opacity: 0 },
      { y: 0, opacity: 1, stagger: 0.11, duration: 0.65, ease: "back.out(1.8)" },
      "-=0.35"
    );

    // 3. "CONTENT" slides from image to LEFT, "STRATEGIST" slides from image to RIGHT
    if (isDesktop) {
      heroTL.fromTo(".nk-hero-word.is-left",
        { x: 150, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.8, ease: "power3.out" },
        "-=0.55"
      );
      heroTL.fromTo(".nk-hero-word.is-right",
        { x: -150, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.8, ease: "power3.out" },
        "<"
      );
    } else {
      heroTL.fromTo(".nk-hero-word.is-left",
        { y: -35, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" },
        "-=0.4"
      );
      heroTL.fromTo(".nk-hero-word.is-right",
        { y: 35, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7, ease: "power3.out" },
        "<"
      );
    }

    // 4. Tag row & orbs pop out
    heroTL.fromTo(".hn-tagrow",
      { scale: 0.4, opacity: 0 },
      { scale: 1, opacity: 1, duration: 0.45, ease: "back.out(2)" },
      "-=0.35"
    );
    heroTL.fromTo(".nk-hero-photo .orb",
      { scale: 0, opacity: 0 },
      { scale: 1, opacity: 1, stagger: 0.12, duration: 0.45, ease: "back.out(2)" },
      "-=0.3"
    );

    // 5. Hero sub card glides up
    heroTL.fromTo(".nk-hero-sub",
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, ease: "power2.out" },
      "-=0.25"
    );
  }
}

/* --------------------------------------------------------------------------
   5. HERO CONTINUOUS MICRO-ANIMATIONS (3D TAG FLIP, LETTER HOVER, PARALLAX)
   -------------------------------------------------------------------------- */
function initHeroAnimations() {
  const tagEl = document.querySelector('.hn-tagrow .hn-w');

  // 3D Tag flip
  if (tagEl && window.gsap) {
    const tags = [
      "DATA x DRAMA",
      "ICONIC HOOKS",
      "CERTIFIED YAPPER",
      "ALGORITHM OBSESSED"
    ];
    let currentIdx = 0;

    setInterval(() => {
      currentIdx = (currentIdx + 1) % tags.length;
      const nextText = tags[currentIdx];

      window.gsap.to(tagEl, {
        rotateX: 90,
        opacity: 0,
        duration: 0.28,
        ease: "power2.in",
        onComplete: () => {
          tagEl.textContent = nextText;
          window.gsap.fromTo(tagEl, 
            { rotateX: -90, opacity: 0 },
            { rotateX: -2, opacity: 1, duration: 0.4, ease: "back.out(1.8)" }
          );
        }
      });
    }, 2800);
  }

  // Interactive hover on "D I Y A ." letters
  const letters = document.querySelectorAll('.hn-big .hn-l');
  letters.forEach(l => {
    l.addEventListener('mouseenter', () => {
      letters.forEach(item => item.classList.remove('is-on'));
      l.classList.add('is-on');
      if (window.gsap) {
        window.gsap.fromTo(l, { scale: 1 }, { scale: 1.25, duration: 0.3, ease: "back.out(2)" });
      }
    });
    l.addEventListener('mouseleave', () => {
      if (window.gsap) {
        window.gsap.to(l, { scale: l.classList.contains('is-on') ? 1.22 : 1, duration: 0.3 });
      }
    });
  });

  // Micro floating motion on Diya's hero photo & orbs
  const heroPhoto = document.querySelector('.nk-hero-photo img');
  const orbs = document.querySelectorAll('.nk-hero-photo .orb');
  if (heroPhoto && window.gsap) {
    window.gsap.to(heroPhoto, {
      y: -8,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });

    // GSAP 7. Image Parallax Drift on Scroll
    if (window.ScrollTrigger) {
      window.gsap.to(heroPhoto, {
        y: 40,
        ease: "none",
        scrollTrigger: {
          trigger: ".nk-hero",
          start: "top top",
          end: "bottom top",
          scrub: 1
        }
      });
    }

    orbs.forEach((orb, i) => {
      window.gsap.to(orb, {
        y: i === 0 ? 6 : -6,
        rotate: i === 0 ? -4 : 4,
        duration: 2.4 + i * 0.6,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut"
      });
    });
  }
}

/* --------------------------------------------------------------------------
   5. QUICK STATS & RESULTS COUNTER ANIMATION
   -------------------------------------------------------------------------- */
function initQuickStatsCountup() {
  const countups = document.querySelectorAll('.countup');
  if (!countups.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const rawText = el.textContent.trim();
        // Parse number from text (e.g. "3.5+", "20+", "553.8", "~38")
        const hasTilde = rawText.startsWith('~');
        const hasPlus = rawText.endsWith('+');
        const hasK = rawText.includes('K');
        const cleanNum = parseFloat(rawText.replace(/[^0-9.]/g, ''));

        if (!isNaN(cleanNum)) {
          const isDecimal = rawText.includes('.');
          const decimals = isDecimal ? (rawText.split('.')[1].replace(/[^0-9]/g, '').length || 1) : 0;
          
          let obj = { val: 0 };
          if (window.gsap) {
            window.gsap.to(obj, {
              val: cleanNum,
              duration: 1.6,
              ease: "power2.out",
              onUpdate: () => {
                let formatted = obj.val.toFixed(decimals);
                if (hasTilde) formatted = '~' + formatted;
                if (hasK) formatted = formatted + 'K';
                if (hasPlus) formatted = formatted + '+';
                el.textContent = formatted;
              }
            });
          }
        }
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.2 });

  countups.forEach(el => observer.observe(el));
}

/* --------------------------------------------------------------------------
   5.5. RESULTS PROOFS EXPAND / COLLAPSE (Max 1 row = 3 proofs by default)
   -------------------------------------------------------------------------- */
function initProofsExpand() {
  const proofsWrap = document.querySelector('.rs-proofs');
  const expandWrap = document.querySelector('.nk-proofs-expand-wrap');
  const resultsSection = document.querySelector('#results');
  if (!proofsWrap || !expandWrap) return;

  const proofCards = Array.from(proofsWrap.querySelectorAll('.rs-proof'));
  const totalCount = proofCards.length;
  const PROOFS_ROW_LIMIT = 3; // 3 items = exactly 1 row on desktop (3-column grid)

  if (totalCount <= PROOFS_ROW_LIMIT) return;

  let isProofsExpanded = false;

  function updateView() {
    proofCards.forEach((card, index) => {
      if (index >= PROOFS_ROW_LIMIT) {
        card.style.display = isProofsExpanded ? 'flex' : 'none';
      }
    });

    if (!isProofsExpanded) {
      expandWrap.innerHTML = `
        <button type="button" class="nk-work-expand-btn" id="proofsExpandBtn" aria-expanded="false">
          <span class="nk-work-expand-text">Explore All ${totalCount} Receipts & Proofs</span>
          <span class="nk-work-expand-icon" aria-hidden="true">↓</span>
        </button>
        <span class="nk-work-expand-badge">Showing 3 of ${totalCount} receipts (1 row)</span>
      `;
    } else {
      expandWrap.innerHTML = `
        <button type="button" class="nk-work-expand-btn is-collapsed-btn" id="proofsExpandBtn" aria-expanded="true">
          <span class="nk-work-expand-text">Show Less</span>
          <span class="nk-work-expand-icon" aria-hidden="true">↑</span>
        </button>
        <span class="nk-work-expand-badge">Showing all ${totalCount} receipts</span>
      `;
    }

    const btn = expandWrap.querySelector('#proofsExpandBtn');
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        toggleProofs();
      });
    }

    if (window.ScrollTrigger) window.ScrollTrigger.refresh();
    if (window.lenis) window.lenis.resize();
  }

  function toggleProofs() {
    isProofsExpanded = !isProofsExpanded;
    updateView();

    if (window.gsap) {
      if (isProofsExpanded) {
        const revealedCards = proofCards.slice(PROOFS_ROW_LIMIT);
        window.gsap.fromTo(revealedCards,
          { opacity: 0, y: 20, scale: 0.98 },
          { opacity: 1, y: 0, scale: 1, duration: 0.38, stagger: 0.05, ease: "back.out(1.2)" }
        );
      } else {
        if (resultsSection) {
          const topY = resultsSection.getBoundingClientRect().top + window.scrollY - 80;
          if (window.lenis) {
            window.lenis.scrollTo(topY, { duration: 0.5 });
          } else {
            window.scrollTo({ top: topY, behavior: 'smooth' });
          }
        }
      }
    }
  }

  // Initial render (collapsed: 3 proofs in 1 row)
  updateView();
}

/* --------------------------------------------------------------------------
   6. SERVICES ACCORDION & GENERAL ACCORDION ENGINE
   -------------------------------------------------------------------------- */
function setupSmoothAccordion(container, itemsData) {
  if (!container) return;

  container.innerHTML = itemsData.map(([title, desc], idx) => {
    const isOpen = idx === 0;
    return `
      <div class="nk-acc-item ${isOpen ? 'is-open' : ''}" data-idx="${idx}">
        <button aria-expanded="${isOpen}" type="button">
          <span>${idx + 1}. ${escapeHtml(title)}</span>
          <i aria-hidden="true" style="display:inline-block; transform: rotate(${isOpen ? 45 : 0}deg);">+</i>
        </button>
        <p style="${isOpen ? 'height: auto; opacity: 1; margin-bottom: 18px; display: block;' : 'height: 0; opacity: 0; margin-bottom: 0; display: none; overflow: hidden;'}">${escapeHtml(desc)}</p>
      </div>
    `;
  }).join('');

  container.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const item = btn.closest('.nk-acc-item');
    if (!item) return;

    const isOpen = item.classList.contains('is-open');

    if (isOpen) {
      closeItem(item);
    } else {
      // Single-open accordion: smoothly close all other open items
      container.querySelectorAll('.nk-acc-item.is-open').forEach(other => {
        if (other !== item) {
          closeItem(other);
        }
      });
      openItem(item);
    }
  });

  function openItem(item) {
    const btn = item.querySelector('button');
    const p = item.querySelector('p');
    const icon = item.querySelector('i');

    item.classList.add('is-open');
    btn.setAttribute('aria-expanded', 'true');

    if (window.gsap && p) {
      window.gsap.killTweensOf(p);
      if (icon) window.gsap.killTweensOf(icon);

      p.style.display = 'block';
      p.style.overflow = 'hidden';
      p.style.height = 'auto';
      const targetHeight = p.offsetHeight;

      window.gsap.fromTo(p,
        {
          height: 0,
          opacity: 0,
          y: -10,
          marginBottom: 0
        },
        {
          height: targetHeight,
          opacity: 1,
          y: 0,
          marginBottom: 18,
          duration: 0.42,
          ease: "power3.out",
          onComplete: () => {
            p.style.height = 'auto';
            if (window.ScrollTrigger) window.ScrollTrigger.refresh();
          }
        }
      );

      if (icon) {
        window.gsap.to(icon, {
          rotate: 45,
          duration: 0.35,
          ease: "back.out(2)"
        });
      }
    } else if (p) {
      p.style.display = 'block';
      p.style.height = 'auto';
      p.style.opacity = '1';
      p.style.marginBottom = '18px';
      if (icon) icon.style.transform = 'rotate(45deg)';
    }
  }

  function closeItem(item) {
    const btn = item.querySelector('button');
    const p = item.querySelector('p');
    const icon = item.querySelector('i');

    item.classList.remove('is-open');
    btn.setAttribute('aria-expanded', 'false');

    if (window.gsap && p) {
      window.gsap.killTweensOf(p);
      if (icon) window.gsap.killTweensOf(icon);

      const startHeight = p.offsetHeight;
      p.style.overflow = 'hidden';

      window.gsap.fromTo(p,
        {
          height: startHeight,
          opacity: 1,
          y: 0,
          marginBottom: 18
        },
        {
          height: 0,
          opacity: 0,
          y: -8,
          marginBottom: 0,
          duration: 0.32,
          ease: "power3.inOut",
          onComplete: () => {
            p.style.display = 'none';
            if (window.ScrollTrigger) window.ScrollTrigger.refresh();
          }
        }
      );

      if (icon) {
        window.gsap.to(icon, {
          rotate: 0,
          duration: 0.3,
          ease: "power2.inOut"
        });
      }
    } else if (p) {
      p.style.display = 'none';
      p.style.height = '0';
      p.style.opacity = '0';
      p.style.marginBottom = '0';
      if (icon) icon.style.transform = 'rotate(0deg)';
    }
  }
}

function initServicesAccordion() {
  const servicesWrap = document.querySelector('.nk-services .nk-acc');
  setupSmoothAccordion(servicesWrap, services);
}

/* --------------------------------------------------------------------------
   7. WORK CATEGORY TABS & DYNAMIC RENDERING (All 7 categories)
   -------------------------------------------------------------------------- */
const WORK_IMGS = {
  "love-podcasts": "./ARS6DUIL.jpg",
  biryan: "./S3PWVBDW.jpg",
  walls: "./JAEIEW3F.jpg",
  city: "./Z2XTUUWY.jpg",
  faces: "./Y56QNJNB.jpg",
  nukkad: "./VEGWG6XZ.jpg"
};

const POP_IMAGES = [
  "./Y4EG6CCM.jpg",
  "./VJJXVYLX.jpg",
  "./VYOVZX4T.jpg",
  "./UUOPAPKS.jpg",
  "./7T6SRKYN.jpg",
  "./FZT6XOQE.jpg"
];

const WORK_THUMBS = {
  "A multi-strategy walkthrough": "./WHMA2ALD.jpg",
  "Creator Revenue Architecture": "./J4CIWBPV.jpg",
  "Mila toh Haathi, Gayi toh Pooch": "./7RT5ZH34.jpg",
  "The founder podcast": "./IWFNTYEV.jpg",
  "Podcast Strategy by Diya": "./JSRGIRDM.jpg",
  "Breaking news, handled": "./AZRQA3A4.jpg",
  "When fiction becomes fact": "./WOGFRNLE.jpg",
  "A novel about a robot": "./QK4PGT5D.jpg",
  "Gamified event marketing": "./IVDS5N3Y.jpg",
  "Homepage + ads, QA’d": "./A7LATOSQ.jpg",
  "Talking reels, A to Z": "./RGGIDX4W.jpg",
  "Scripts with a pulse": "./XPANUF67.jpg",
  "Tools, reviewed": "./5VQMVEAO.jpg",
  "Seller’s paradise": "./TSWX5BQ5.jpg",
  "Level up your data game": "./P6MJW5M6.jpg",
  "A rebrand, page by page": "./CCCH6TSV.jpg",
  "The 3-volume brand": "./EDQJNRDF.jpg",
  "Luck shouldn’t decide fame": "./G66JJWFL.jpg",
  "Seek Ease": "./FX3M2B7P.jpg",
  "AskIVA": "./JQSMRGUG.jpg",
  "Glow, wireframed": "./YZ6FCLPJ.jpg",
  "Shock-math in 5 seconds": "./5R6WT77H.jpg",
  "Founder-led B2B": "./7GG7Q2WA.jpg",
  "Taste of Home, Miles Away": "./HPZHSKX4.jpg",
  "Helter, but strategic": "./KCAWNZKI.jpg",
  "70+ pieces, one engine": "./5GRKOBKJ.jpg",
  "Listicles, reviews, face-offs": "./5GRKOBKJ.jpg",
  "Dermatologist approved": "./D4BAXOHL.jpg",
  "Kahani, in Hindi": "./6RDO7DI7.jpg",
  "Reviewer to lifestyle brand": "./7DOEAXHJ.jpg",
  "58K views and counting": "./ZWUBLP4Y.jpg",
  "2025 Ka Manhoos Saal": "./CLBWN37G.svg",
  "The 1-person AI business": "./URZPG72K.png",
  "Pattern hunting": "./URZPG72K.png",
  "300K+ readers a month": "./FZH72YH3.png",
  "B2B, but make it clear": "./5JSIJCE2.png",
  "Best Facial Moisturizers": "./CMPG4IQJ.svg",
  "Backlinks with manners": "./VNUTS6RC.svg",
  "Affordable luxury": "./OKJRRSRM.svg"
};

const DARK_THUMBS = new Set(["./CLBWN37G.svg", "./URZPG72K.png", "./OKJRRSRM.svg", "./KCAWNZKI.jpg"]);
const WORK_TONES = ["ink", "lime", "cream", "coral", "lilac", "yellow"];
const WORK_MOTIFS = ["num", "ring", "stripe", "quote", "grid", "arrow"];

function renderWorkCover(piece, no, drawerKey) {
  if (piece.img && WORK_IMGS[piece.img]) {
    return `
      <div class="cv cv-photo">
        <img src="${WORK_IMGS[piece.img]}" alt="${escapeHtml(piece.title)} campaign cover" loading="lazy">
        <span class="cv-issue">No. ${String(no).padStart(2, '0')}</span>
      </div>
    `;
  }
  const tone = WORK_TONES[(no * 7 + drawerKey.length) % WORK_TONES.length];
  const motif = WORK_MOTIFS[(no * 5 + drawerKey.length * 3) % WORK_MOTIFS.length];
  const th = WORK_THUMBS[piece.title];
  const isDark = th && DARK_THUMBS.has(th);

  let motifText = '';
  if (motif === 'num') motifText = String(no).padStart(2, '0');
  else if (motif === 'quote') motifText = '“';
  else if (motif === 'arrow') motifText = '↗';

  const clientShort = piece.client ? piece.client.split(/[,(:/]/)[0].trim() : '';

  return `
    <div class="cv cv-${tone} cv-m-${motif}${th ? ' cv-hasdoc' : ''}" aria-hidden="true">
      <div class="cv-top">
        <span class="cv-mast">DN.</span>
        <span class="cv-issue">No. ${String(no).padStart(2, '0')}</span>
      </div>
      ${th ? `<img class="cv-doc ${isDark ? 'is-dk' : ''}" src="${th}" alt="">` : ''}
      <div class="cv-motif">${motifText}</div>
      <h4 class="cv-title">${escapeHtml(piece.title)}</h4>
      <div class="cv-bottom">
        <span>${escapeHtml(piece.tag || '')}</span>
        <span>${escapeHtml(clientShort)}</span>
      </div>
    </div>
  `;
}

function initWorkTabs() {
  const workSection = document.querySelector('#work.nk-work');
  const tabsWrap = document.querySelector('.nk-work .nk-tabs');
  const piecesWrap = document.querySelector('.nk-work .nk-pieces');
  const blurbEl = document.querySelector('.nk-drawer-blurb');
  let expandWrap = document.querySelector('.nk-work .nk-work-expand-wrap');

  if (!tabsWrap || !piecesWrap) return;

  if (!expandWrap && workSection) {
    expandWrap = document.createElement('div');
    expandWrap.className = 'nk-work-expand-wrap';
    piecesWrap.after(expandWrap);
  }

  // Compute issue number offsets across all 7 drawers (total 58 pieces)
  const offsets = {};
  let counter = 0;
  drawers.forEach((d) => {
    offsets[d.key] = counter;
    counter += d.pieces.length;
  });

  let currentKey = drawers[0].key;
  let isWorkExpanded = false; // Default: show max 1 row
  let isTransitioning = false;
  const ROW_LIMIT = 3;

  // Render drawer category chips dynamically
  tabsWrap.innerHTML = drawers.map((d, i) => `
    <button role="tab" aria-selected="${i === 0}" class="${i === 0 ? 'is-on' : ''}" data-key="${d.key}">
      ${escapeHtml(d.label)} (${d.pieces.length})
    </button>
  `).join('');

  // Function to build HTML string and container class for a category
  function buildContent(key, expanded) {
    const drawer = drawers.find(d => d.key === key) || drawers[0];
    const totalCount = drawer.pieces.length;
    const items = (!expanded && totalCount > ROW_LIMIT)
      ? drawer.pieces.slice(0, ROW_LIMIT)
      : drawer.pieces;

    if (workSection) {
      workSection.classList.toggle('is-collapsed', !expanded);
    }

    if (key === 'pop') {
      return {
        isPop: true,
        totalCount,
        hasMore: totalCount > ROW_LIMIT,
        html: items.map((p, i) => `
          <a class="pop-tile r${i % 3}" href="${linkFor('Pop-culture copies')}" target="_blank" rel="noopener noreferrer">
            <img src="${POP_IMAGES[i]}" alt="Pop-culture copy: ${escapeHtml(p.title)}" loading="lazy">
            <span class="pop-cap">
              <b>${escapeHtml(p.tag)}</b>
              ${escapeHtml(p.title)}
            </span>
          </a>
        `).join('')
      };
    }

    return {
      isPop: false,
      totalCount,
      hasMore: totalCount > ROW_LIMIT,
      html: items.map((p, i) => {
        const issueNo = offsets[key] + i + 1;
        const isLead = expanded && i === 0;
        const coverHtml = renderWorkCover(p, issueNo, key);
        const href = linkFor(p.title);
        const linkText = (href === PORTFOLIO_ROOT) ? 'Browse the portfolio' : 'See the work';

        return `
          <article class="nk-piece ${isLead ? 'is-lead' : ''}">
            ${coverHtml}
            <div class="nk-piece-body">
              <p class="nk-piece-tag">${escapeHtml(p.tag || '')}</p>
              <h3>${escapeHtml(p.title)}</h3>
              <p class="nk-piece-client">${escapeHtml(p.client || '')}</p>
              <p>${escapeHtml(p.text || '')}</p>
              <a class="nk-piece-link" href="${href}" target="_blank" rel="noopener noreferrer">${linkText} ↗</a>
            </div>
          </article>
        `;
      }).join('')
    };
  }

  // Update Expand / Collapse button state
  function updateExpandButton(hasMore, totalCount) {
    if (!expandWrap) return;
    if (!hasMore) {
      expandWrap.innerHTML = '';
      return;
    }

    const drawer = drawers.find(d => d.key === currentKey);
    const categoryName = drawer ? drawer.label.split('(')[0].trim() : 'Pieces';

    if (!isWorkExpanded) {
      expandWrap.innerHTML = `
        <button type="button" class="nk-work-expand-btn" id="workExpandBtn" aria-expanded="false">
          <span class="nk-work-expand-text">Explore All ${totalCount} ${escapeHtml(categoryName)}</span>
          <span class="nk-work-expand-icon" aria-hidden="true">↓</span>
        </button>
        <span class="nk-work-expand-badge">Showing 3 of ${totalCount} pieces (1 row)</span>
      `;
    } else {
      expandWrap.innerHTML = `
        <button type="button" class="nk-work-expand-btn is-collapsed-btn" id="workExpandBtn" aria-expanded="true">
          <span class="nk-work-expand-text">Show Less</span>
          <span class="nk-work-expand-icon" aria-hidden="true">↑</span>
        </button>
        <span class="nk-work-expand-badge">Showing all ${totalCount} pieces</span>
      `;
    }

    const btn = expandWrap.querySelector('#workExpandBtn');
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        toggleExpand();
      });
    }
  }

  // Toggle expand/collapse with smooth GSAP animations
  function toggleExpand() {
    isWorkExpanded = !isWorkExpanded;
    const built = buildContent(currentKey, isWorkExpanded);

    if (!isWorkExpanded) {
      // Collapsing back to 1 row
      piecesWrap.innerHTML = built.html;
      updateExpandButton(built.hasMore, built.totalCount);
      if (window.gsap) {
        window.gsap.fromTo(piecesWrap.children,
          { opacity: 0.6, y: -8 },
          { opacity: 1, y: 0, duration: 0.28, stagger: 0.03, ease: "power2.out" }
        );
      }
      // Smoothly scroll back to tabs so view is centered
      if (workSection) {
        const topY = workSection.getBoundingClientRect().top + window.scrollY - 80;
        if (window.lenis) {
          window.lenis.scrollTo(topY, { duration: 0.5 });
        } else {
          window.scrollTo({ top: topY, behavior: 'smooth' });
        }
      }
    } else {
      // Expanding to show all cards
      piecesWrap.innerHTML = built.html;
      updateExpandButton(built.hasMore, built.totalCount);
      if (window.gsap) {
        const newCards = Array.from(piecesWrap.children).slice(ROW_LIMIT);
        window.gsap.fromTo(newCards,
          { opacity: 0, y: 22, scale: 0.97 },
          { opacity: 1, y: 0, scale: 1, duration: 0.42, stagger: 0.035, ease: "back.out(1.2)" }
        );
      }
    }

    if (window.ScrollTrigger) window.ScrollTrigger.refresh();
    if (window.lenis) window.lenis.resize();
  }

  // Smooth tab switch animation (resets to collapsed 1-row by default)
  function switchTab(key) {
    if (isTransitioning || key === currentKey) return;
    isTransitioning = true;
    isWorkExpanded = false; // Always default to max 1 row on category switch

    tabsWrap.querySelectorAll('button').forEach(btn => {
      const isSelected = btn.dataset.key === key;
      btn.classList.toggle('is-on', isSelected);
      btn.setAttribute('aria-selected', isSelected ? 'true' : 'false');
      if (isSelected && window.gsap) {
        window.gsap.fromTo(btn, { scale: 0.94 }, { scale: 1, duration: 0.28, ease: "back.out(2)" });
      }
    });

    const nextDrawer = drawers.find(d => d.key === key) || drawers[0];
    const oldCards = Array.from(piecesWrap.children);

    if (window.gsap && oldCards.length > 0) {
      const tl = window.gsap.timeline({
        onComplete: () => {
          currentKey = key;
          const built = buildContent(key, isWorkExpanded);
          piecesWrap.className = built.isPop ? 'pop-wall' : 'nk-pieces';
          piecesWrap.innerHTML = built.html;
          if (blurbEl) blurbEl.textContent = nextDrawer.blurb;
          updateExpandButton(built.hasMore, built.totalCount);

          const newCards = Array.from(piecesWrap.children);
          window.gsap.fromTo(newCards,
            { opacity: 0, y: 22, scale: 0.97 },
            {
              opacity: 1,
              y: 0,
              scale: 1,
              duration: 0.4,
              stagger: 0.04,
              ease: "back.out(1.2)",
              onComplete: () => {
                isTransitioning = false;
                if (window.ScrollTrigger) window.ScrollTrigger.refresh();
                if (window.lenis) window.lenis.resize();
              }
            }
          );

          if (blurbEl) {
            window.gsap.fromTo(blurbEl,
              { opacity: 0, y: 8 },
              { opacity: 1, y: 0, duration: 0.35, ease: "power2.out" }
            );
          }
        }
      });

      tl.to(oldCards, {
        opacity: 0,
        y: -12,
        scale: 0.98,
        duration: 0.18,
        stagger: 0.015,
        ease: "power2.in"
      }, 0);

      if (blurbEl) {
        tl.to(blurbEl, {
          opacity: 0,
          y: -6,
          duration: 0.15,
          ease: "power2.in"
        }, 0);
      }
    } else {
      currentKey = key;
      const built = buildContent(key, isWorkExpanded);
      piecesWrap.className = built.isPop ? 'pop-wall' : 'nk-pieces';
      piecesWrap.innerHTML = built.html;
      if (blurbEl) blurbEl.textContent = nextDrawer.blurb;
      updateExpandButton(built.hasMore, built.totalCount);
      isTransitioning = false;
      if (window.ScrollTrigger) window.ScrollTrigger.refresh();
      if (window.lenis) window.lenis.resize();
    }
  }

  // Initial render of first category (collapsed: max 1 row)
  const initialBuilt = buildContent(currentKey, isWorkExpanded);
  piecesWrap.className = initialBuilt.isPop ? 'pop-wall' : 'nk-pieces';
  piecesWrap.innerHTML = initialBuilt.html;
  if (blurbEl) blurbEl.textContent = drawers[0].blurb;
  updateExpandButton(initialBuilt.hasMore, initialBuilt.totalCount);

  // Tab click event delegation
  tabsWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const key = btn.dataset.key;
    if (key) switchTab(key);
  });
}

// Helper to resolve project images to local assets
function resolveImage(key) {
  const defaultImages = [
    './S3PWVBDW.jpg', './JAEIEW3F.jpg', './Z2XTUUWY.jpg', './Y56QNJNB.jpg',
    './VEGWG6XZ.jpg', './HPZHSKX4.jpg', './G66JJWFL.jpg', './J4CIWBPV.jpg',
    './WHMA2ALD.jpg', './IVDS5N3Y.jpg', './A7LATOSQ.jpg', './FX3M2B7P.jpg',
    './KCAWNZKI.jpg', './BWFIZXH2.jpg', './LWSRVUMP.jpg', './FZH72YH3.png'
  ];
  if (ASSET_MAP && ASSET_MAP[key]) {
    return './' + ASSET_MAP[key];
  }
  if (ASSET_MAP && ASSET_MAP[key + '_default']) {
    return './' + ASSET_MAP[key + '_default'];
  }
  // Fallback to cycling default high-res local images
  let hash = 0;
  for (let i = 0; i < key.length; i++) hash = (hash + key.charCodeAt(i)) % defaultImages.length;
  return defaultImages[hash];
}

/* --------------------------------------------------------------------------
   8. JOURNEY TABS & EXPANDABLE 1-ROW VIEW (Corporate, Clients, Education, Milestones)
   -------------------------------------------------------------------------- */
function initJourneyTabs() {
  const tabsWrap = document.querySelector('.nk-journey .nk-tabs');
  const timelineEl = document.querySelector('.nk-timeline');
  const expandWrap = document.querySelector('.nk-journey-expand-wrap');
  const journeySection = document.querySelector('#journey');
  if (!tabsWrap || !timelineEl) return;

  const JOURNEY_ROW_LIMIT = 2; // 2 items = exactly 1 row on desktop (2-column grid)
  let currentChapter = 'corporate';
  let isJourneyExpanded = false;

  function renderChapter(chapter) {
    currentChapter = chapter;
    let totalCount = 0;
    let hasMore = false;
    let html = '';

    if (chapter === 'clients') {
      totalCount = clientGroups.length;
      hasMore = totalCount > JOURNEY_ROW_LIMIT;
      const displayedGroups = (!isJourneyExpanded && hasMore)
        ? clientGroups.slice(0, JOURNEY_ROW_LIMIT)
        : clientGroups;

      html = displayedGroups.map(cg => `
        <li>
          <div class="nk-tl-top">
            <span class="nk-year">Client Roster</span>
            <p class="nk-tl-role" style="font-size: 16px;">${escapeHtml(cg.k)}</p>
          </div>
          <div class="nk-client-tags">
            ${cg.items.map(item => `<span class="nk-client-tag">${escapeHtml(item)}</span>`).join('')}
          </div>
        </li>
      `).join('');
    } else {
      const items = journey[chapter] || journey.corporate;
      totalCount = items.length;
      hasMore = totalCount > JOURNEY_ROW_LIMIT;
      const displayedItems = (!isJourneyExpanded && hasMore)
        ? items.slice(0, JOURNEY_ROW_LIMIT)
        : items;

      html = displayedItems.map(item => {
        // Convert markdown bold **word** to <strong>word</strong>
        const formattedDesc = escapeHtml(item.d).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        const points = formattedDesc.split('\n').filter(Boolean);
        return `
          <li>
            <div class="nk-tl-top">
              <span class="nk-year">${escapeHtml(item.y)}</span>
            </div>
            <div>
              <p class="nk-tl-role">${escapeHtml(item.r)}</p>
              <p class="nk-tl-org">${escapeHtml(item.o)}</p>
              <ul class="tl-pts">
                ${points.map(pt => `<li>${pt}</li>`).join('')}
              </ul>
            </div>
          </li>
        `;
      }).join('');
    }

    timelineEl.innerHTML = html;
    updateExpandButton(hasMore, totalCount, chapter);

    if (window.ScrollTrigger) window.ScrollTrigger.refresh();
    if (window.lenis) window.lenis.resize();
  }

  function updateExpandButton(hasMore, totalCount, chapter) {
    if (!expandWrap) return;
    if (!hasMore) {
      expandWrap.innerHTML = '';
      return;
    }

    const chapterTitles = {
      corporate: 'Corporate Chapters',
      clients: 'Client Categories',
      education: 'Education & Courses',
      milestones: 'Milestones & Honors'
    };
    const label = chapterTitles[chapter] || 'Items';

    if (!isJourneyExpanded) {
      expandWrap.innerHTML = `
        <button type="button" class="nk-work-expand-btn" id="journeyExpandBtn" aria-expanded="false">
          <span class="nk-work-expand-text">Explore All ${totalCount} ${label}</span>
          <span class="nk-work-expand-icon" aria-hidden="true">↓</span>
        </button>
        <span class="nk-work-expand-badge">Showing 2 of ${totalCount} (1 row)</span>
      `;
    } else {
      expandWrap.innerHTML = `
        <button type="button" class="nk-work-expand-btn is-collapsed-btn" id="journeyExpandBtn" aria-expanded="true">
          <span class="nk-work-expand-text">Show Less</span>
          <span class="nk-work-expand-icon" aria-hidden="true">↑</span>
        </button>
        <span class="nk-work-expand-badge">Showing all ${totalCount} ${label.toLowerCase()}</span>
      `;
    }

    const btn = expandWrap.querySelector('#journeyExpandBtn');
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        toggleExpand();
      });
    }
  }

  function toggleExpand() {
    isJourneyExpanded = !isJourneyExpanded;
    renderChapter(currentChapter);

    if (window.gsap) {
      if (isJourneyExpanded) {
        const newCards = Array.from(timelineEl.children).slice(JOURNEY_ROW_LIMIT);
        window.gsap.fromTo(newCards,
          { opacity: 0, y: 18, scale: 0.98 },
          { opacity: 1, y: 0, scale: 1, duration: 0.35, stagger: 0.04, ease: "back.out(1.2)" }
        );
      } else {
        window.gsap.fromTo(timelineEl.children,
          { opacity: 0.7, y: -6 },
          { opacity: 1, y: 0, duration: 0.25, stagger: 0.03, ease: "power2.out" }
        );
        if (journeySection) {
          const topY = journeySection.getBoundingClientRect().top + window.scrollY - 80;
          if (window.lenis) {
            window.lenis.scrollTo(topY, { duration: 0.5 });
          } else {
            window.scrollTo({ top: topY, behavior: 'smooth' });
          }
        }
      }
    }
  }

  // Initial render (defaults to collapsed 1 row)
  renderChapter('corporate');

  tabsWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const text = btn.textContent.trim().toLowerCase();

    tabsWrap.querySelectorAll('button').forEach(b => {
      b.classList.remove('is-on');
      b.setAttribute('aria-selected', 'false');
    });
    btn.classList.add('is-on');
    btn.setAttribute('aria-selected', 'true');

    isJourneyExpanded = false; // Reset to 1 row on tab change
    renderChapter(text);

    if (window.gsap) {
      window.gsap.fromTo(timelineEl.children,
        { opacity: 0, y: 14 },
        { opacity: 1, y: 0, duration: 0.35, stagger: 0.04, ease: "power2.out" }
      );
    }
  });
}

/* --------------------------------------------------------------------------
   9. FAQ ACCORDION (Interactive Expand/Collapse for all 6 FAQs)
   -------------------------------------------------------------------------- */
function initFaqAccordion() {
  const faqWrap = document.querySelector('.nk-faq .nk-acc');
  setupSmoothAccordion(faqWrap, faqs);
}

/* --------------------------------------------------------------------------
   10. TESTIMONIALS SLIDER & ARROWS (Autoplay + Touch / Mouse Drag)
   -------------------------------------------------------------------------- */
function initTestimonialsSlider() {
  const marquee = document.querySelector('.tm-marquee');
  const prevBtn = document.querySelector('.tm-arrows button:first-child');
  const nextBtn = document.querySelector('.tm-arrows button:last-child');
  if (!marquee) return;

  const scrollAmount = 450;

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      marquee.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    });
  }
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      marquee.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    });
  }

  // Auto-play slider every 4.5 seconds (pausing on hover / interaction)
  let autoTimer = null;
  function startAutoPlay() {
    stopAutoPlay();
    autoTimer = setInterval(() => {
      if (marquee.scrollLeft + marquee.clientWidth >= marquee.scrollWidth - 10) {
        marquee.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        marquee.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }, 4500);
  }
  function stopAutoPlay() {
    if (autoTimer) clearInterval(autoTimer);
  }

  startAutoPlay();
  marquee.addEventListener('mouseenter', stopAutoPlay);
  marquee.addEventListener('mouseleave', startAutoPlay);
  marquee.addEventListener('touchstart', stopAutoPlay, { passive: true });
  marquee.addEventListener('touchend', startAutoPlay);

  // Mouse drag support
  let isDown = false;
  let startX;
  let scrollLeft;

  marquee.addEventListener('mousedown', (e) => {
    isDown = true;
    marquee.classList.add('active');
    startX = e.pageX - marquee.offsetLeft;
    scrollLeft = marquee.scrollLeft;
    stopAutoPlay();
  });
  marquee.addEventListener('mouseleave', () => {
    isDown = false;
    marquee.classList.remove('active');
    startAutoPlay();
  });
  marquee.addEventListener('mouseup', () => {
    isDown = false;
    marquee.classList.remove('active');
    startAutoPlay();
  });
  marquee.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - marquee.offsetLeft;
    const walk = (x - startX) * 1.5;
    marquee.scrollLeft = scrollLeft - walk;
  });
}

/* --------------------------------------------------------------------------
   IRL FAVS HORIZONTAL CAROUSEL SWIPE & DRAG (#rooms)
   -------------------------------------------------------------------------- */
function initFavsCarousel() {
  const row = document.querySelector('.st-row');
  if (!row) return;

  let isDown = false;
  let startX;
  let scrollLeft;

  row.addEventListener('mousedown', (e) => {
    isDown = true;
    row.classList.add('active');
    startX = e.pageX - row.offsetLeft;
    scrollLeft = row.scrollLeft;
  });
  row.addEventListener('mouseleave', () => {
    isDown = false;
    row.classList.remove('active');
  });
  row.addEventListener('mouseup', () => {
    isDown = false;
    row.classList.remove('active');
  });
  row.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - row.offsetLeft;
    const walk = (x - startX) * 1.5;
    row.scrollLeft = scrollLeft - walk;
  });
}

/* --------------------------------------------------------------------------
   11. LETTER DETAILS ACCORDION
   -------------------------------------------------------------------------- */
function initLetterDetails() {
  const details = document.querySelector('.lt-scroll');
  if (!details) return;

  details.addEventListener('toggle', () => {
    if (details.open && window.gsap) {
      const paper = details.querySelector('.lt-paper');
      if (paper) {
        window.gsap.fromTo(paper, 
          { opacity: 0, scaleY: 0.85, transformOrigin: "top center" },
          { opacity: 1, scaleY: 1, duration: 0.6, ease: "power3.out" }
        );
      }
    }
  });
}

/* --------------------------------------------------------------------------
   12. GSAP SCROLL REVEAL ANIMATIONS
   -------------------------------------------------------------------------- */
function initScrollReveals() {
  if (typeof window.gsap === "undefined" || typeof window.ScrollTrigger === "undefined") return;

  // Subtle stamp animation on section serif headings
  document.querySelectorAll('h2.nk-serif').forEach(heading => {
    window.gsap.from(heading, {
      scale: 0.96,
      y: 12,
      duration: 0.6,
      ease: "power2.out",
      scrollTrigger: {
        trigger: heading,
        start: "top 92%",
        toggleActions: "play none none none"
      }
    });
  });

  // Stagger entrance on QuickStats cards
  const qsGrid = document.querySelector('.qs-grid');
  if (qsGrid) {
    window.gsap.fromTo(qsGrid.children,
      { opacity: 0, y: 30, scale: 0.95 },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: 0.55,
        stagger: 0.1,
        ease: "power2.out",
        scrollTrigger: {
          trigger: qsGrid,
          start: "top 85%",
          toggleActions: "play none none none"
        }
      }
    );
  }

  // Stagger entrance on Playground cards
  const pgGrid = document.querySelector('.pg-grid');
  if (pgGrid) {
    window.gsap.fromTo(pgGrid.children,
      { opacity: 0, y: 36 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.12,
        ease: "power2.out",
        scrollTrigger: {
          trigger: pgGrid,
          start: "top 85%",
          toggleActions: "play none none none"
        }
      }
    );
  }

  // Stagger entrance on Results Proofs
  const proofsWrap = document.querySelector('.rs-proofs');
  if (proofsWrap) {
    window.gsap.fromTo(proofsWrap.children,
      { opacity: 0, y: 24 },
      {
        opacity: 1,
        y: 0,
        duration: 0.5,
        stagger: 0.08,
        ease: "power2.out",
        scrollTrigger: {
          trigger: proofsWrap,
          start: "top 85%",
          toggleActions: "play none none none"
        }
      }
    );
  }

  // Floating tilt on about & services photos
  const aboutPhoto = document.querySelector('.nk-about-photo img');
  if (aboutPhoto) {
    window.gsap.to(aboutPhoto, {
      rotate: 4.5,
      y: -6,
      duration: 3.5,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
  }
  const servicesPhoto = document.querySelector('.nk-services-photo img');
  if (servicesPhoto) {
    window.gsap.to(servicesPhoto, {
      rotate: -3.5,
      y: -6,
      duration: 3.2,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
  }
}

/* --------------------------------------------------------------------------
   13. TACTILE MICRO-HOVER EFFECTS
   -------------------------------------------------------------------------- */
function initMicroHoverEffects() {
  // Magnet hover on buttons
  const buttons = document.querySelectorAll('.nk-btn, .nk-nav button, .tm-arrows button');
  buttons.forEach(btn => {
    btn.addEventListener('mouseenter', () => {
      if (window.gsap) {
        window.gsap.to(btn, { scale: 1.05, duration: 0.2, ease: "back.out(2)" });
      }
    });
    btn.addEventListener('mouseleave', () => {
      if (window.gsap) {
        window.gsap.to(btn, { scale: 1, duration: 0.2, ease: "power2.out" });
      }
    });
  });
}

/* --------------------------------------------------------------------------
   14. CLAPPERBOARD SCROLL ENTRANCE & INTERACTIVE MOUSE HOVER TILT
   -------------------------------------------------------------------------- */
function initClapperAnimation() {
  const clapBoard = document.querySelector('.mc-clap');
  const clapTop = document.querySelector('.mc-top');
  if (!clapBoard || !window.gsap) return;

  const baseRotate = 5; // Resting natural rotation in degrees

  // 1. Entrance animation on scroll up into view
  const triggerElement = clapBoard.closest('.nk-about-photo') || clapBoard;

  if (window.ScrollTrigger) {
    window.gsap.fromTo(
      clapBoard,
      {
        y: 85,
        opacity: 0,
        scale: 0.84,
        rotate: -14
      },
      {
        y: 0,
        opacity: 1,
        scale: 1,
        rotate: baseRotate,
        duration: 1.05,
        ease: "back.out(1.7)",
        scrollTrigger: {
          trigger: triggerElement,
          start: "top 85%",
          toggleActions: "play none none none"
        }
      }
    );

    if (clapTop) {
      window.gsap.fromTo(
        clapTop,
        { rotate: -24 },
        {
          rotate: -6,
          duration: 0.5,
          delay: 0.35,
          ease: "bounce.out",
          scrollTrigger: {
            trigger: triggerElement,
            start: "top 85%",
            toggleActions: "play none none none"
          }
        }
      );
    }
  }

  // 2. Interactive mousemove tilt & follow
  const onMouseMove = (e) => {
    const rect = clapBoard.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    // Normalized offset from center: -1 to 1
    const normX = Math.max(-1.5, Math.min(1.5, (e.clientX - centerX) / (rect.width / 2)));
    const normY = Math.max(-1.5, Math.min(1.5, (e.clientY - centerY) / (rect.height / 2)));

    // Subtle magnetic drift (up to ~18px) and responsive angular tilt
    const targetX = normX * 18;
    const targetY = normY * 16;
    const targetRotate = baseRotate + normX * 8;

    window.gsap.to(clapBoard, {
      x: targetX,
      y: targetY,
      rotate: targetRotate,
      scale: 1.05,
      duration: 0.28,
      ease: "power2.out",
      overwrite: "auto"
    });
  };

  const onMouseLeave = () => {
    window.gsap.to(clapBoard, {
      x: 0,
      y: 0,
      rotate: baseRotate,
      scale: 1,
      duration: 0.75,
      ease: "elastic.out(1.1, 0.4)",
      overwrite: "auto"
    });
  };

  clapBoard.addEventListener('mouseenter', onMouseMove);
  clapBoard.addEventListener('mousemove', onMouseMove);
  clapBoard.addEventListener('mouseleave', onMouseLeave);

  // 3. Tactile click "snap clap" interaction
  clapBoard.addEventListener('click', () => {
    if (clapTop) {
      window.gsap.timeline()
        .to(clapTop, { rotate: -26, duration: 0.1, ease: "power2.out" })
        .to(clapTop, { rotate: -6, duration: 0.25, ease: "bounce.out" });
    }
  });
}

/* --------------------------------------------------------------------------
   15. PROCESS WHITE CARDS CUTE TILT ON HOVER
   -------------------------------------------------------------------------- */
function initProcessCardsTilt() {
  const prTrack = document.querySelector('.pr-track');
  const cards = document.querySelectorAll('.pr-step');
  if (!cards.length || !window.gsap) return;

  // 1. Staggered cute entrance on scroll
  if (prTrack && window.ScrollTrigger) {
    window.gsap.fromTo(
      cards,
      {
        opacity: 0,
        y: 40,
        scale: 0.9,
        rotateZ: (i) => (i % 2 === 0 ? -4 : 4)
      },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        rotateZ: 0,
        duration: 0.75,
        stagger: 0.09,
        ease: "back.out(1.8)",
        scrollTrigger: {
          trigger: prTrack,
          start: "top 85%",
          toggleActions: "play none none none"
        }
      }
    );
  }

  // 2. Cute tilt and mouse follow on hover
  cards.forEach((card, idx) => {
    // Alternating playful personality tilt: card 0: -2.2deg, card 1: +2.2deg, card 2: -2.2deg, card 3: +2.2deg
    const baseTilt = idx % 2 === 0 ? -2.2 : 2.2;
    const nextArrow = card.nextElementSibling && card.nextElementSibling.classList.contains('pr-arrow')
      ? card.nextElementSibling
      : null;

    const onMouseMove = (e) => {
      const rect = card.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      // Normalized coordinates (-1 to 1)
      const normX = Math.max(-1.2, Math.min(1.2, (e.clientX - centerX) / (rect.width / 2)));
      const normY = Math.max(-1.2, Math.min(1.2, (e.clientY - centerY) / (rect.height / 2)));

      // Cute dynamic 3D + 2D tilt
      const targetX = normX * 8;
      const targetY = -8 + normY * 5; // Float upwards with subtle vertical follow
      const targetRotateZ = baseTilt + normX * 4;
      const targetRotateX = -normY * 8;
      const targetRotateY = normX * 10;

      window.gsap.to(card, {
        x: targetX,
        y: targetY,
        rotateZ: targetRotateZ,
        rotateX: targetRotateX,
        rotateY: targetRotateY,
        scale: 1.05,
        duration: 0.24,
        ease: "power2.out",
        overwrite: "auto"
      });

      if (nextArrow) {
        window.gsap.to(nextArrow, {
          x: 5,
          scale: 1.15,
          duration: 0.24,
          ease: "power2.out",
          overwrite: "auto"
        });
      }
    };

    const onMouseLeave = () => {
      window.gsap.to(card, {
        x: 0,
        y: 0,
        rotateZ: 0,
        rotateX: 0,
        rotateY: 0,
        scale: 1,
        duration: 0.65,
        ease: "elastic.out(1.2, 0.4)",
        overwrite: "auto"
      });

      if (nextArrow) {
        window.gsap.to(nextArrow, {
          x: 0,
          scale: 1,
          duration: 0.4,
          ease: "power2.out",
          overwrite: "auto"
        });
      }
    };

    card.addEventListener('mouseenter', onMouseMove);
    card.addEventListener('mousemove', onMouseMove);
    card.addEventListener('mouseleave', onMouseLeave);

    // Cute squish bounce on click
    card.addEventListener('click', () => {
      window.gsap.timeline()
        .to(card, { scale: 0.94, duration: 0.1, ease: "power2.in" })
        .to(card, { scale: 1.05, duration: 0.25, ease: "back.out(2)" });
    });
  });
}

// Utility: Escape HTML to prevent injection
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
